﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.CAD
{
    public class comentarioCAD
    {
        private string conexion;


    }
}